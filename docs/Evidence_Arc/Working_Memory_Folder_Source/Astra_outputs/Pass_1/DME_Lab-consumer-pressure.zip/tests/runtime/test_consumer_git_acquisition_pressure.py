from __future__ import annotations

import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from src.ledger import JsonlLedger
from src.reconstruction import reconstruct_admission_relationships
from src.runtime.consumer_git_acquisition_pressure import build, digest, serialized
from src.runtime.foreground_repository_observation import ForegroundRepositoryObservationCoordinator


class ConsumerGitAcquisitionPressureTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.report = build()

    def test_complete_live_surfaces_collide_across_opposite_acquisition_outcomes(self) -> None:
        cases = list(self.report['cases'].values())
        self.assertEqual(serialized(cases[0]['surface']), serialized(cases[1]['surface']))
        by_fixture = {case['audit']['fixture_has_git']: case for case in cases}
        healthy = by_fixture[True]['audit']['raw_git']
        failed = by_fixture[False]['audit']['raw_git']
        self.assertEqual(healthy['capture_errors'], [])
        self.assertTrue(healthy['head_sha'])
        self.assertEqual(healthy['branch'], 'main')
        self.assertEqual(healthy['status_porcelain'], [])
        self.assertEqual(len(failed['capture_errors']), 3)
        self.assertTrue(all('not a git repository' in item['error'] for item in failed['capture_errors']))
        for field in ('head_sha', 'branch', 'status_porcelain'):
            self.assertIsNone(failed[field])

    def test_navigation_preserves_source_evidence_without_capture_or_append(self) -> None:
        for case in self.report['cases'].values():
            self.assertEqual(case['audit']['raw_filesystem_errors'], [])
            self.assertTrue(case['audit']['recovery_appended_nothing'])
            recovered = case['audit']['recovered_git']
            self.assertEqual(recovered['observation_record_id'], 'rec-000002')
            self.assertEqual(recovered['observation']['signal']['payload'], case['audit']['raw_git'])
            self.assertEqual(recovered['admissions'][0]['decision'], 'admitted')
        canonical = self.report['canonical_history']
        self.assertEqual(canonical['sha256_before'], canonical['sha256_after'])

    def test_recorded_specimen_ledgers_reproduce_entire_consumer_packets(self) -> None:
        trace = json.loads(Path('traces/consumer_git_acquisition_pressure_v0.json').read_text(encoding='utf-8'))
        with TemporaryDirectory() as temporary:
            for label, case in trace['cases'].items():
                history = Path(temporary) / f'{label}.jsonl'
                original = case['audit']['ledger_jsonl'].encode('utf-8')
                history.write_bytes(original)
                self.assertEqual(hashlib.sha256(original).hexdigest(), case['audit']['ledger_sha256'])
                self.assertTrue(JsonlLedger(history).verify().ok)
                # A nonexistent root is intentional: current_result must not capture.
                coordinator = ForegroundRepositoryObservationCoordinator(Path(temporary) / 'absent', history)
                replayed_surface = coordinator.current_result()
                coordinator.close()
                self.assertEqual(replayed_surface, case['surface'])
                self.assertEqual(digest(replayed_surface), case['surface_sha256'])
                self.assertEqual(history.read_bytes(), original)
                reconstruction = reconstruct_admission_relationships(JsonlLedger(history).replay())
                git = next(item for item in reconstruction['observations'] if item['source'] == 'repository_git_state')
                self.assertEqual(git, case['audit']['recovered_git'])


if __name__ == '__main__':
    unittest.main()
