"""One pressure fixture over the unchanged foreground current_result surface.

This constructs evidence, not a consumer, policy, or production interface.
The consumer's prose is recorded separately before the audit is opened.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import secrets
from tempfile import TemporaryDirectory

from src.ledger import JsonlLedger
from src.reconstruction import reconstruct_admission_relationships
from src.runtime.degraded_git_admission_pressure import _initialize_git, _write_alpha
from src.runtime.foreground_repository_observation import (
    ForegroundRepositoryObservationCoordinator,
)


QUESTION = (
    "Does this recovered result establish that its historical Git observation "
    "successfully acquired HEAD, branch, and working-tree status, so that you "
    "can summarize that captured Git state? State what is warranted and the "
    "smallest evidence request or proposed action. Do not claim current external state."
)
WITHHELD = [
    "fixture identity and whether it is a Git repository",
    "immediate capture_round result and raw source observations",
    "authoritative ledger bytes, nested observations, and full reconstruction",
    "source command outcomes, capture_errors, HEAD, branch, and working-tree status",
    "which specimen is healthy or degraded and the paired specimen's result",
]


def serialized(value: object) -> bytes:
    # Serialization only: no fields or values are dropped, renamed, or normalized.
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value: object) -> str:
    return hashlib.sha256(serialized(value)).hexdigest()


def build() -> dict:
    canonical = Path("traces/live_ingest_ledger_v0.jsonl")
    before = hashlib.sha256(canonical.read_bytes()).hexdigest()
    specimens = []
    with TemporaryDirectory(prefix="dme-consumer-") as temporary:
        base = Path(temporary)
        for is_git in (True, False):
            directory = base / ("git" if is_git else "directory")
            root = directory / "fixture"
            root.mkdir(parents=True)
            _write_alpha(root)
            if is_git:
                _initialize_git(root)
            history = directory / "history.jsonl"
            coordinator = ForegroundRepositoryObservationCoordinator(root, history)
            immediate = coordinator.capture_round()
            coordinator.close()
            ledger_bytes = history.read_bytes()
            recovered = ForegroundRepositoryObservationCoordinator.open(root, history)
            surface = recovered.current_result()
            recovered.close()
            records = JsonlLedger(history).replay()
            reconstruction = reconstruct_admission_relationships(records)
            git_subject = next(
                item for item in reconstruction["observations"]
                if item["source"] == "repository_git_state"
            )
            specimens.append({
                "surface": surface,
                "surface_sha256": digest(surface),
                "audit": {
                    "fixture_has_git": is_git,
                    "raw_git": immediate["captured_observations"]["git"],
                    "raw_filesystem_errors": immediate["captured_observations"]["filesystem"]["capture_errors"],
                    "ledger_jsonl": ledger_bytes.decode("utf-8"),
                    "ledger_sha256": hashlib.sha256(ledger_bytes).hexdigest(),
                    "recovered_git": git_subject,
                    "recovery_appended_nothing": ledger_bytes == history.read_bytes(),
                },
            })
    # Labels convey no source condition. The mapping stays in withheld evidence.
    secrets.SystemRandom().shuffle(specimens)
    return {
        "experiment": "consumer_git_acquisition_pressure_v0",
        "upstream_head": "2618453d233a5867757c22ff732459f701834372",
        "question": QUESTION,
        "visible_basis": "Entire unmodified return of a fresh coordinator current_result(); one opaque case handle; this question.",
        "withheld_evidence": WITHHELD,
        "consumer_context_limit": "Same assistant designed the fixture and has read implementation and prior D-0046 evidence; new specimen mapping and underlying evidence are withheld until audit. This is not a blind or independent model evaluation.",
        "cases": dict(zip(("A", "B"), specimens)),
        "canonical_history": {
            "sha256_before": before,
            "sha256_after": hashlib.sha256(canonical.read_bytes()).hexdigest(),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "paired", "audit"))
    parser.add_argument("evidence", type=Path)
    args = parser.parse_args()
    if args.stage == "prepare":
        if args.evidence.exists():
            raise FileExistsError("Refusing to replace an existing specimen")
        result = build()
        args.evidence.parent.mkdir(parents=True, exist_ok=True)
        args.evidence.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps({"case": "A", "question": QUESTION, "visible_evidence": result["cases"]["A"]["surface"]}, indent=2))
    else:
        result = json.loads(args.evidence.read_text(encoding="utf-8"))
        a, b = (result["cases"][key] for key in ("A", "B"))
        if args.stage == "paired":
            print(json.dumps({
                "case": "B", "visible_evidence": b["surface"],
                "exact_surface_equality": serialized(a["surface"]) == serialized(b["surface"]),
                "question": "Can the complete current_result representation distinguish the two historical acquisition outcomes? Choose a supported case-specific action, or explain what prevents a choice. Do not use hidden fixture truth.",
            }, indent=2))
        else:
            print(json.dumps({
                "exact_surface_equality": serialized(a["surface"]) == serialized(b["surface"]),
                "surface_sha256": a["surface_sha256"],
                "cases": {
                    key: {
                        "fixture_has_git": case["audit"]["fixture_has_git"],
                        "raw_git": case["audit"]["raw_git"],
                        "recovered_git": case["audit"]["recovered_git"],
                        "recovery_appended_nothing": case["audit"]["recovery_appended_nothing"],
                    } for key, case in result["cases"].items()
                },
                "canonical_history": result["canonical_history"],
            }, indent=2))


if __name__ == "__main__":
    main()
