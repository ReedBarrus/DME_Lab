"""Temporary association selection fixtures; run from a DME_Lab checkout.

No production files are changed. Specimen creation uses the existing APIs.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(Path.cwd()))
from src.ingest import append_admission
from src.ledger import JsonlLedger, verify_continuity, validate_ledger_record
from src.reconstruction import reconstruct_admission_relationships
from src.runtime.degraded_git_admission_pressure import _initialize_git, _write_alpha
from src.runtime.foreground_repository_observation import ForegroundRepositoryObservationCoordinator as Coordinator
from public_reader import PROFILE, canonical, computed_digests, read_packet, sha


KINDS = ('locator_only', 'extent', 'record_ids', 'terminal_digest', 'target_digest',
         'exact_bytes', 'ordered_record_digests', 'prefix_digest', 'full_prefix_records')
FINALISTS = ('ordered_record_digests', 'prefix_digest')


def stored_records(path, records):
    """Create a separate independently committed history from declared envelopes."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    ledger = JsonlLedger(path)
    for record in records:
        ledger.append(deepcopy(record['envelope']), record_id=record['record_id'])
    return ledger.replay()


def current(path):
    # No available source root: this operation must recover without capture.
    before = path.read_bytes()
    reader = Coordinator.open(path.parent / 'source_not_present', path)
    result = reader.current_result()
    reader.close()
    assert path.read_bytes() == before
    return result


def inspect(path):
    ledger = JsonlLedger(path)
    records = ledger.replay()
    health = {
        'schema': all(validate_ledger_record(r).valid for r in records),
        'integrity': ledger.verify().ok,
        'continuity': verify_continuity(records, require_start_at_one=True).ok,
    }
    assert all(health.values()), health
    return {'records': records, 'jsonl': path.read_text(encoding='utf-8'),
            'file_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'health': health, 'result': current(path)}


def target_of(result):
    return next(r['observation_record_id'] for r in result['derived']['projection']
                if r['source'] == 'repository_git_state')


def commitment(kind, records, raw, target):
    digests = computed_digests(records)
    return {
        'locator_only': None,
        'extent': len(records),
        'record_ids': [r['record_id'] for r in records],
        'terminal_digest': digests[-1],
        'target_digest': next(d for r, d in zip(records, digests) if r['record_id'] == target),
        'exact_bytes': hashlib.sha256(raw).hexdigest(),
        'ordered_record_digests': digests,
        'prefix_digest': sha(digests),
        'full_prefix_records': [{k: r[k] for k in PROFILE['record_boundary']} for r in records],
    }[kind]


def packet(kind, original, uri, raw=None):
    records, result = original['records'], original['result']
    return {'public_contract': deepcopy(PROFILE), 'result': deepcopy(result),
            'association': {'history_uri': uri, 'kind': kind,
                            'commitment': commitment(kind, records,
                                raw if raw is not None else original['jsonl'].encode('utf-8'),
                                target_of(result))}}


def extend(path, source_record):
    ledger = JsonlLedger(path)
    observation = ledger.append(deepcopy(source_record['envelope']))
    append_admission(ledger, observation)


def run():
    canonical_path = Path('traces/live_ingest_ledger_v0.jsonl')
    canonical_before = hashlib.sha256(canonical_path.read_bytes()).hexdigest()
    results = {'starting_ref': 'cb8b916184d1e42e720834a62a68b4b4e0ace49c',
               'phase': 'exploratory_selection', 'candidate_kinds': list(KINDS),
               'specimens': {}, 'matrix': [], 'component_ablations': [],
               'detached_reads': [], 'collision_controls': {}, 'extensions': []}
    with TemporaryDirectory(prefix='dme-association-') as temporary:
        base = Path(temporary)
        root = base / 'same_source_root'
        root.mkdir()
        _write_alpha(root)
        paths = {}
        for name, initialize in (('D4', False), ('H4', True)):
            if initialize:
                _initialize_git(root)
            paths[name] = base / 'histories' / f'{name}.jsonl'
            writer = Coordinator(root, paths[name])
            writer.capture_round()
            writer.close()
            results['specimens'][name] = inspect(paths[name])
        h4 = results['specimens']['H4']
        d4 = results['specimens']['D4']
        assert h4['result'] == d4['result']

        def add(name, records):
            paths[name] = base / 'histories' / f'{name}.jsonl'
            stored_records(paths[name], records)
            results['specimens'][name] = inspect(paths[name])

        # Same IDs, different roles; every admission is created by the real API.
        paths['roles4'] = base / 'histories' / 'roles4.jsonl'
        ledger = JsonlLedger(paths['roles4'])
        for record in h4['records'][:2]:
            observation = ledger.append(deepcopy(record['envelope']))
            append_admission(ledger, observation)
        results['specimens']['roles4'] = inspect(paths['roles4'])
        add('copy_H4', h4['records'])
        for index in range(4):
            altered = deepcopy(h4['records'])
            # Allowed envelope metadata; source observations themselves unchanged.
            altered[index]['envelope']['association_pressure_annotation'] = f'alternate-{index}'
            add(f'changed_{index + 1}', altered)
            assert results['specimens'][f'changed_{index + 1}']['result'] == h4['result']
        renamed = deepcopy(h4['records'])
        mapping = {r['record_id']: f'alternative-{i + 1}' for i, r in enumerate(renamed)}
        for record in renamed:
            record['record_id'] = mapping[record['record_id']]
            if 'subject_record_id' in record['envelope']:
                record['envelope']['subject_record_id'] = mapping[record['envelope']['subject_record_id']]
        add('renamed4', renamed)
        for name, source in (('H6', h4['records'][1]), ('H6_other_tail', h4['records'][0])):
            add(name, h4['records'])
            extend(paths[name], source)
            results['specimens'][name] = inspect(paths[name])
        add('H3', h4['records'][:3])
        canonical_records = JsonlLedger(canonical_path).replay()
        add('H14', canonical_records)
        add('H16', canonical_records)
        extend(paths['H16'], next(r for r in canonical_records if r['envelope'].get('record_type') == 'observation'))
        results['specimens']['H16'] = inspect(paths['H16'])

        # Same committed content represented by reordered JSONL lines and CRLF.
        paths['reencoded_H4'] = base / 'histories' / 'reencoded_H4.jsonl'
        paths['reencoded_H4'].write_bytes(('\r\n'.join(json.dumps(r, ensure_ascii=False)
                                                   for r in reversed(h4['records'])) + '\r\n').encode('utf-8'))
        results['specimens']['reencoded_H4'] = inspect(paths['reencoded_H4'])
        assert results['specimens']['reencoded_H4']['result'] == h4['result']

        # All candidate locations are publicly supplied; no fixture label selects a history.
        slot = base / 'public' / 'history.jsonl'
        slot.parent.mkdir()
        packets = {kind: packet(kind, h4, slot.as_uri()) for kind in KINDS}
        results['packets_H4'] = packets
        for name, specimen in results['specimens'].items():
            slot.write_bytes(paths[name].read_bytes())
            for kind, declaration in packets.items():
                outcome = read_packet(declaration, target_of(h4['result']))
                results['matrix'].append({'kind': kind, 'available_history': name,
                                          'outcome': outcome,
                                          'same_original_prefix': specimen['records'][:4] == h4['records']})

        for source, available in (('H4', 'H6'), ('H4', 'H6_other_tail'), ('H14', 'H16')):
            original = results['specimens'][source]
            slot.write_bytes(paths[available].read_bytes())
            for kind in ('exact_bytes', *FINALISTS):
                declaration = packet(kind, original, slot.as_uri())
                results['extensions'].append({'kind': kind, 'source': source,
                                               'available': available,
                                               'outcome': read_packet(declaration, target_of(original['result']))})

        # Removing one element while preserving original positional interpretation.
        # A null marks an omitted commitment; positions are not renumbered.
        for index in range(4):
            values = computed_digests(h4['records'])
            values[index] = None
            alternative = results['specimens'][f'changed_{index + 1}']
            matches = all(w is None or w == d for w, d in zip(values, computed_digests(alternative['records'])))
            results['component_ablations'].append({
                'carrier': 'ordered_record_digests', 'removed_prefix_position': index + 1,
                'accepted_wrong_prefix_under_weakened_rule': matches,
                'alternative': f'changed_{index + 1}',
                'full_result_equal': alternative['result'] == h4['result'],
            })
        slot.write_bytes(paths['H4'].read_bytes())
        for kind in FINALISTS:
            original_packet = packets[kind]
            for component in ('history_uri', 'commitment', 'public_contract'):
                weakened = deepcopy(original_packet)
                if component == 'public_contract':
                    weakened.pop(component)
                else:
                    weakened['association'].pop(component)
                results['component_ablations'].append({'carrier': kind, 'removed': component,
                                                       'outcome': read_packet(weakened, target_of(h4['result']))})
            for key in PROFILE:
                weakened = deepcopy(original_packet)
                weakened['public_contract'].pop(key)
                results['component_ablations'].append({'carrier': kind, 'removed_public_semantics': key,
                                                       'outcome': read_packet(weakened, target_of(h4['result']))})

        # Copying a packet does not require the source root or a live coordinator.
        transport = base / 'detached_transport'
        transport.mkdir()
        for source, available in (('H4', 'H4'), ('D4', 'D4'), ('H14', 'H16')):
            original = results['specimens'][source]
            for kind in FINALISTS:
                p = packet(kind, original, paths[available].as_uri())
                detached = transport / f'{source}-{kind}.json'
                detached.write_text(json.dumps(p), encoding='utf-8')
                before = hashlib.sha256(paths[available].read_bytes()).hexdigest()
                completed = subprocess.run([sys.executable, str(HERE / 'public_reader.py'), str(detached), target_of(original['result'])], cwd=transport, check=True, capture_output=True, text=True)
                outcome = json.loads(completed.stdout)
                results['detached_reads'].append({'source': source, 'available': available,
                    'kind': kind, 'outcome': outcome, 'subprocess_returncode': completed.returncode,
                    'ledger_unchanged': before == hashlib.sha256(paths[available].read_bytes()).hexdigest(),
                    'consumer_imports_DME': False, 'packet_json_roundtrip_equal': json.loads(detached.read_text()) == p})

        # Content-only witness lacks a location and cannot distinguish copies/tails.
        matching = [name for name, s in results['specimens'].items()
                    if computed_digests(s['records'][:4]) == computed_digests(h4['records'])]
        results['collision_controls'] = {
            'same_root_for_H4_D4': str(root),
            'same_repository_revision_for_all': results['starting_ref'],
            'H4_D4_full_result_equal': h4['result'] == d4['result'],
            'H4_D4_terminal_digest_equal': computed_digests(h4['records'])[-1] == computed_digests(d4['records'])[-1],
            'histories_matching_content_witness_without_location': matching,
            'renamed_ids_same_source_payload': h4['records'][1]['envelope']['observation'] == results['specimens']['renamed4']['records'][1]['envelope']['observation'],
            'renamed_own_association': {kind: read_packet(packet(kind, results['specimens']['renamed4'], paths['renamed4'].as_uri()), target_of(results['specimens']['renamed4']['result'])) for kind in FINALISTS},
        }
        # An unavailable locator remains missing; no fallback to a convenient history.
        for kind in FINALISTS:
            missing = packet(kind, h4, (base / 'not_supplied.jsonl').as_uri())
            results['component_ablations'].append({'carrier': kind, 'unavailable_location': True,
                'outcome': read_packet(missing, target_of(h4['result']))})
    results['canonical_history_sha256_before'] = canonical_before
    results['canonical_history_sha256_after'] = hashlib.sha256(canonical_path.read_bytes()).hexdigest()
    return results


if __name__ == '__main__':
    report = run()
    (HERE / 'selection_trace.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'specimens': len(report['specimens']), 'candidate_cells': len(report['matrix']),
                     'all_histories_valid': all(all(s['health'].values()) for s in report['specimens'].values()),
                     'collision_controls': report['collision_controls'],
                     'matrix_statuses': {k: {r['available_history']: r['outcome']['status'] for r in report['matrix'] if r['kind'] == k} for k in KINDS},
                     'extensions': report['extensions'], 'detached_reads': report['detached_reads']}, indent=2))
