# Experimental public association declaration

This document is part of the candidate supplied to a consumer. It is not an
existing DME public contract or adopted representation. A consumer needs no DME
implementation source to apply the following rules.

A packet carries the unchanged complete `result`, an `association`, and this
explicit `public_contract`. The producer asserts their association. This is not
a signature, proof of producer identity, or proof that the result was generated
by executing a particular program. The pressure checks committed-content
correspondence and recovery, assuming the original packet was paired faithfully.

1. Open `association.history_uri` as an absolute file URI on the declared local
   execution host. No search or record-ID resolution is implied. Missing access
   means unavailable; never substitute another file with the same name or IDs.
2. Parse JSONL, sort by integer `commit_index`, and require dense indices starting
   at one and unique record IDs. Recompute each record's SHA-256 over canonical
   `{record_id, commit_index, envelope}`. Canonical means UTF-8 JSON, sorted keys,
   compact comma/colon separators, unescaped Unicode (`ensure_ascii=False`).
   Compare to the stored digest. Stored algorithm/boundary labels do not choose
   the algorithm. These rules restate the bounded existing commitment semantics.
3. Read N from `result.ledger.record_count`, already present in the result.
   Require at least N available records. The association concerns only the first
   N committed records, not the entire available history after continuation.
4. For `ordered_record_digests`, compare the complete ordered list of N recomputed
   record digests to `association.commitment`.
   For `prefix_digest`, hash the canonical JSON array of those N lowercase
   hexadecimal digest strings with SHA-256 and compare that hash to commitment.
   These are separate candidate encodings. No hash collision is assumed or
   demonstrated. The second introduces a new aggregate commitment boundary.

   Adversarial-pass candidates: `digest_set` interprets the commitment list as
   an unordered set of distinct record digests and requires equality with the
   set recomputed over the first N records. Serialization order has no meaning.
   `digest_set_hash` hashes the canonical JSON array of that set's lowercase
   hexadecimal strings sorted lexicographically. It introduces a different
   aggregate boundary. Canonical replay order still selects the first N records.
5. A mismatch does not identify another history or authorize repair. A match
   establishes the declared committed prefix at this location within hash and
   access assumptions. Copies or distinct continuations may contain the same
   prefix; it does not identify a unique physical store or complete current tail.
6. Within that matched prefix, follow the result's observation IDs and admitted
   record IDs. Check observation source/type and admission subject/type/decision.
   For the target Git observation, expose the nested observation's signal payload
   fields HEAD, branch, status, and capture errors. Missing fields remain missing.
   Report recorded command errors or recorded field availability. Neither
   structural admission nor a commitment match establishes source success.
7. Do not claim current-world freshness, capture simultaneity, historical truth,
   global record identity, source trust, or general navigation from this procedure.

The location must remain available. Moving only the detached packet preserves
the absolute location; moving/deleting the evidence can make it unavailable.
Cross-host reachability is not promised. A future adoption would require a public
association export operation and stable evidence access, neither added here.
