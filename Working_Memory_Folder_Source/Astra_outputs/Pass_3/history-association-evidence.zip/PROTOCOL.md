# Association-carrier selection: pre-execution basis

Starting remote/main: cb8b916184d1e42e720834a62a68b4b4e0ace49c.
Standing: investigator experiment under the supplied warrant; no repository adoption.

Question: What is the smallest public association sufficient to bind a detached
current_result() to the authoritative historical evidence from which its record
references derive, for the already-demonstrated Git-acquisition consumer question?

Observation: execute existing capture, append, replay, reconstruction, and
current_result on independent temporary histories. Compare association candidates
against committed records, not against a fixture-name oracle. A standalone reader
may use an explicitly supplied experimental public declaration, JSON packets, and
the supplied evidence URI; it must not import DME implementation.

Candidate families: no carrier; source/root; repository revision; trace name or
identity; capture invocation; locator; digest alone; locator with extent/IDs;
locator with terminal or selected-record digests; locator with byte-exact history
digest; locator with ordered prefix-record digests; locator with an aggregate
commitment to those ordered prefix digests; immutable revision plus artifact path;
full embedded history as a cost/control case. Candidates can be eliminated by
construction evidence or by missing operational support; these are different.

Serious live comparisons will separate reachability from commitment checking.
An absolute file URI is a deliberately bounded local-host reachability carrier.
It conveys a producer's declared association, not authenticated publisher origin.
No filesystem search, digest lookup index, server, or global namespace is added.

Mandatory constructions: independent healthy/degraded histories with equal full
results; same root with different histories; same IDs with changed roles; same
source payload re-recorded under different IDs; admissible continuation; independent
replacement histories; fresh coordinator recovery; JSON transport to another
process. All alternate histories must pass schema, record integrity, and dense
start-at-one continuity. Replacements are separate valid histories supplied at
the same candidate location, not amendments to the original authoritative ledger.

For strong candidates, attempt changes at every committed prefix position while
preserving the complete result, omission of each commitment component, an absent
locator, an absent semantic declaration, an exact copy at another location, and
two extensions sharing an original prefix. Check whether a wrong target record or
a different original prefix is accepted. Do not assume physical store identity
is the same as committed-content identity.

Exact-history and containing-prefix semantics will both be exercised. A preserved
original prefix may answer the historical question after continuation; acceptance
must not claim that the available suffix was part of the original result.

The experiment can test candidate public interpretability through a standalone
implementation of its written declaration. That is not a new unfamiliar-human
or LLM usability trial. Novel observations formulate candidates; a separately
declared adversarial pass must precede recommendation.

Stop with one of the four warrant statuses. Preserve multiple surviving carriers
when functional evidence and the nine-dimensional cost/claim vector do not
establish a unique necessity ordering. No aggregate score or taste-based winner.
