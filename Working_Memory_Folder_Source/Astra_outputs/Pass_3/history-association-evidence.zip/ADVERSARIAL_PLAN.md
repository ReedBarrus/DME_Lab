# Separate adversarial pass, declared after selection_trace.json

Selection execution retained ordered per-record prefix commitments and a
single aggregate commitment. No preferred carrier is yet declared minimal.

Attempt 1: create a valid mixed-origin history retaining the healthy Git record
and terminal admission while replacing a different committed observation with
the separately captured observation from the same source root. Preserve R.
Expect sparse target/terminal commitments to accept this different prefix;
require full-prefix candidates to reject it.

Attempt 2: remove the ordering of the per-record witness itself. Each existing
record digest commits to commit_index. Candidate N unordered digests, compared
with the first N recomputed record digests after continuity/canonical replay,
may discriminate every tested prefix without witness-order metadata. This is
an attempted falsification of ordered-carrier minimality. Public ordering for
finding the first N records remains necessary context; these are different roles.

Candidate comparison will include the unordered set and a hash of its canonical
sorted encoding. They remain exploratory candidates until this pass executes.
Reverse their serialized set order, remove each distinct digest, and challenge
with the mixed-origin history, opposite source outcome, role swaps, tail loss,
copies, and the existing continuation specimens.

Attempt 3: two different valid continuations share the exact original prefix.
If the carrier is described as selecting one whole current history or physical
store, this is a counterexample. For the historical question, check whether both
recover the same original committed record, without making suffix/freshness claims.

Location ablation means no public way to reach evidence. Commitment ablation
means a path plus R can accept the opposite acquisition history. Withholding
the public declaration must leave interpretation unresolved. A reader's refusal
on missing declaration is a contract guard, not a proof that every word or
metadata field in that declaration is minimal.

If more than one encoding has the same bounded discrimination but different
representation/implementation costs, stop with unresolved candidate choice.
