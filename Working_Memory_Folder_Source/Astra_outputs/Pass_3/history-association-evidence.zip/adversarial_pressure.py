"""Run the separately declared attacks on selection candidates."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from run_pressure import HERE, inspect, packet, stored_records, target_of
from public_reader import computed_digests, read_packet, sha


FINAL = ('digest_set', 'prefix_digest', 'digest_set_hash')


def declaration(kind, original, uri):
    value = packet('ordered_record_digests', original, uri)
    value['association']['kind'] = kind
    digests = computed_digests(original['records'])
    value['association']['commitment'] = {
        'digest_set': sorted(set(digests)),
        'prefix_digest': sha(digests),
        'digest_set_hash': sha(sorted(set(digests))),
    }[kind]
    return value


def run():
    selection_bytes = (HERE / 'selection_trace.json').read_bytes()
    selection = json.loads(selection_bytes)
    originals = selection['specimens']
    h4, d4 = originals['H4'], originals['D4']
    output = {
        'selection_trace_sha256': hashlib.sha256(selection_bytes).hexdigest(),
        'plan_sha256': hashlib.sha256((HERE / 'ADVERSARIAL_PLAN.md').read_bytes()).hexdigest(),
        'candidate_encodings': list(FINAL), 'matrix': [], 'set_ablations': [],
        'order_ablation': [], 'detached_reads': [], 'extensions': [],
    }
    with TemporaryDirectory(prefix='dme-association-adversary-') as temporary:
        base = Path(temporary)
        slot = base / 'public_history.jsonl'
        mixed = deepcopy(h4['records'])
        mixed[0] = deepcopy(d4['records'][0])
        stored_records(slot, mixed)
        mixed_specimen = inspect(slot)
        assert mixed_specimen['result'] == h4['result']
        assert mixed_specimen['records'] != h4['records']
        output['new_mixed_specimen'] = mixed_specimen
        output['target_and_terminal_unchanged'] = all(
            mixed_specimen['records'][i] == h4['records'][i] for i in (1, 3))
        for kind in ('target_digest', 'terminal_digest', 'ordered_record_digests'):
            p = packet(kind, h4, slot.as_uri())
            output.setdefault('mixed_sparse_attack', {})[kind] = read_packet(p, target_of(h4['result']))

        specimens = dict(originals, mixed4=mixed_specimen)
        for name, specimen in specimens.items():
            stored_records(slot, specimen['records'])
            for kind in FINAL:
                p = declaration(kind, h4, slot.as_uri())
                output['matrix'].append({'kind': kind, 'available_history': name,
                                         'outcome': read_packet(p, target_of(h4['result']))})
        stored_records(slot, h4['records'])
        p = declaration('digest_set', h4, slot.as_uri())
        for arrangement in (p['association']['commitment'], list(reversed(p['association']['commitment']))):
            modified = deepcopy(p)
            modified['association']['commitment'] = arrangement
            output['order_ablation'].append({'serialized_commitment': arrangement,
                'outcome': read_packet(modified, target_of(h4['result']))})

        witness = set(computed_digests(h4['records']))
        for index, removed in enumerate(computed_digests(h4['records'])):
            weakened = witness - {removed}
            alternate = originals[f'changed_{index + 1}']
            output['set_ablations'].append({
                'removed_commitment_for_index': index + 1,
                'alternative': f'changed_{index + 1}',
                'same_complete_result': alternate['result'] == h4['result'],
                'weakened_subset_rule_accepts_wrong_prefix': weakened <= set(computed_digests(alternate['records'])),
                'full_set_rule_rejects': witness != set(computed_digests(alternate['records'])),
            })

        for source, available in (('H4', 'H6'), ('H4', 'H6_other_tail'), ('H14', 'H16')):
            stored_records(slot, originals[available]['records'])
            for kind in FINAL:
                p = declaration(kind, originals[source], slot.as_uri())
                outcome = read_packet(p, target_of(originals[source]['result']))
                output['extensions'].append({'source': source, 'available': available,
                                             'kind': kind, 'outcome': outcome})

        # Execute finalists from detached JSON in processes with no DME imports.
        for source, available in (('H4', 'H4'), ('D4', 'D4'), ('H14', 'H16')):
            stored_records(slot, originals[available]['records'])
            for kind in FINAL:
                p = declaration(kind, originals[source], slot.as_uri())
                detached = base / f'{source}-{kind}.json'
                detached.write_text(json.dumps(p), encoding='utf-8')
                before = slot.read_bytes()
                completed = subprocess.run([sys.executable, str(HERE / 'public_reader.py'), str(detached), target_of(originals[source]['result'])], cwd=base, check=True, capture_output=True, text=True)
                output['detached_reads'].append({'source': source, 'available': available,
                    'kind': kind, 'packet': p, 'outcome': json.loads(completed.stdout),
                    'ledger_unchanged': slot.read_bytes() == before, 'new_process': True})

        output['locator_and_commitment_ablation'] = []
        stored_records(slot, d4['records'])
        for kind in FINAL:
            without_locator = declaration(kind, h4, slot.as_uri())
            without_locator['association'].pop('history_uri')
            missing_contract = declaration(kind, h4, slot.as_uri())
            missing_contract.pop('public_contract')
            output['locator_and_commitment_ablation'].append({
                'kind': kind,
                'no_locator': read_packet(without_locator, target_of(h4['result'])),
                'no_public_contract': read_packet(missing_contract, target_of(h4['result'])),
                'commitment_check_removed': read_packet(packet('locator_only', h4, slot.as_uri()), target_of(h4['result'])),
                'full_candidate': read_packet(declaration(kind, h4, slot.as_uri()), target_of(h4['result'])),
            })

    output['functional_equivalence_on_matrix'] = all(
        len({json.dumps(row['outcome'], sort_keys=True) for row in output['matrix'] if row['available_history'] == name}) == 1
        for name in specimens)
    output['whole_current_history_uniqueness_refuted'] = (
        originals['H6']['records'] != originals['H6_other_tail']['records']
        and originals['H6']['records'][:4] == originals['H6_other_tail']['records'][:4] == h4['records'])
    output['primary_status'] = 'multiple_history_association_candidates_remain'
    return output


if __name__ == '__main__':
    report = run()
    (HERE / 'adversarial_trace.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({key: report[key] for key in (
        'primary_status', 'target_and_terminal_unchanged', 'mixed_sparse_attack',
        'order_ablation', 'set_ablations', 'functional_equivalence_on_matrix',
        'whole_current_history_uniqueness_refuted')}, indent=2))
