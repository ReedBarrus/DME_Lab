"""Standalone implementation of PUBLIC_ASSOCIATION.md; no DME imports.

Experimental local-file consumer, not a resolver service or production module.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit
from urllib.request import url2pathname


PROFILE = {
    'hash': 'SHA-256',
    'record_boundary': ['record_id', 'commit_index', 'envelope'],
    'canonicalization': 'JSON UTF-8; sorted keys; compact separators; ensure_ascii=False',
    'ordering': 'ascending integer commit_index; unique IDs; dense indices starting at 1',
    'relation': 'prefix of available history; length from result.ledger.record_count',
    'location': 'absolute local file URI, interpreted on the declared execution host',
}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def computed_digests(records):
    return [sha({key: r[key] for key in PROFILE['record_boundary']}) for r in records]


def read_packet(packet, target):
    association = packet.get('association', {})
    if packet.get('public_contract') != PROFILE:
        return {'status': 'unresolved_interpretation'}
    uri = association.get('history_uri')
    if not uri:
        return {'status': 'unresolved_location'}
    split = urlsplit(uri)
    if split.scheme != 'file' or split.netloc not in ('', 'localhost'):
        return {'status': 'unsupported_location'}
    try:
        path = Path(url2pathname(split.path))
        if not path.is_absolute():
            return {'status': 'unsupported_location'}
        raw = path.read_bytes()
    except OSError:
        return {'status': 'unavailable_history'}
    try:
        records = [json.loads(line) for line in raw.splitlines() if line.strip()]
        if any(type(r['commit_index']) is not int for r in records):
            return {'status': 'invalid_history'}
        records.sort(key=lambda r: r['commit_index'])
        if [r['commit_index'] for r in records] != list(range(1, len(records) + 1)):
            return {'status': 'invalid_history'}
        if len({r['record_id'] for r in records}) != len(records):
            return {'status': 'invalid_history'}
        calculated = computed_digests(records)
        if any(r['integrity']['digest'] != d for r, d in zip(records, calculated)):
            return {'status': 'invalid_history'}
        n = packet['result']['ledger']['record_count']
        if type(n) is not int or n < 1 or len(records) < n:
            return {'status': 'mismatched_extent'}
        prefix = records[:n]
        values = {
            'locator_only': None,
            'extent': n,
            'record_ids': [r['record_id'] for r in prefix],
            'terminal_digest': calculated[n - 1],
            'target_digest': next((d for r, d in zip(prefix, calculated) if r['record_id'] == target), None),
            'ordered_record_digests': calculated[:n],
            'prefix_digest': sha(calculated[:n]),
            'digest_set': sorted(set(calculated[:n])),
            'digest_set_hash': sha(sorted(set(calculated[:n]))),
            'exact_bytes': hashlib.sha256(raw).hexdigest(),
            'full_prefix_records': [{k: r[k] for k in PROFILE['record_boundary']} for r in prefix],
        }
        kind = association.get('kind')
        if kind not in values:
            return {'status': 'unresolved_interpretation'}
        supplied = association.get('commitment')
        if kind == 'digest_set' and isinstance(supplied, list):
            supplied = sorted(set(supplied))
        if values[kind] != supplied:
            return {'status': 'mismatched_commitment'}
        # Check the exposed references' roles rather than substituting equal IDs.
        by_id = {r['record_id']: r for r in prefix}
        for row in packet['result']['derived']['projection']:
            obs = by_id.get(row['observation_record_id'])
            if (obs is None or obs['envelope'].get('record_type') != 'observation'
                    or obs['envelope'].get('source') != row['source']
                    or row['subject_record_id'] != row['observation_record_id']):
                return {'status': 'mismatched_reference'}
            for aid in row['admission_record_ids']:
                admission = by_id.get(aid, {}).get('envelope', {})
                if (admission.get('record_type') != 'admission'
                        or admission.get('subject_record_id') != row['subject_record_id']
                        or admission.get('decision') != 'admitted'):
                    return {'status': 'mismatched_reference'}
        row = next((r for r in packet['result']['derived']['projection']
                    if r['observation_record_id'] == target and r['source'] == 'repository_git_state'), None)
        if row is None:
            return {'status': 'unresolved_target'}
        payload = by_id[target]['envelope']['observation']['signal']['payload']
        fields = ('head_sha', 'branch', 'status_porcelain', 'capture_errors')
        observed = {k: payload[k] for k in fields if k in payload}
        if len(observed) != len(fields):
            conclusion = 'acquisition_unresolved_missing_fields'
        elif observed['capture_errors']:
            conclusion = 'recorded_capture_errors_present'
        elif any(observed[k] is None for k in fields[:3]):
            conclusion = 'acquisition_unresolved_null_fields'
        else:
            conclusion = 'recorded_fields_available_without_capture_errors'
        return {
            'status': 'recovered', 'historical_git': observed,
            'historical_conclusion': conclusion, 'prefix_record_count': n,
            'available_record_count': len(records), 'target_record_id': target,
            'current_external_state': 'unobserved',
            'authority': 'supplied association assertion; no publisher authentication',
        }
    except (KeyError, TypeError, ValueError, UnicodeError):
        return {'status': 'invalid_or_insufficient_evidence'}


if __name__ == '__main__':
    print(json.dumps(read_packet(json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')), sys.argv[2]), sort_keys=True))
