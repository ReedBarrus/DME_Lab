# Reproduce the bounded association investigation

Use a clean checkout of `ReedBarrus/DME_Lab` at `cb8b916184d1e42e720834a62a68b4b4e0ace49c`, Python, and Git. Extract this evidence archive into a separate directory outside that checkout. The experimental scripts use Python's standard library and the checkout's existing APIs.

From the checkout directory, run (replace the example absolute evidence path):

```powershell
python C:\path\to\evidence\test_pressure.py
python -m unittest discover -s tests
```

The first command replays saved specimen records through the existing ledger and coordinator and checks the recorded counterexamples. It does not perform a fresh source capture. Git may require your normal safe-directory configuration for the checkout when running the repository suite.

To repeat the entire generation and separately declared adversarial execution, first copy the extracted evidence directory to a new scratch directory, then run from the pinned checkout:

```powershell
python C:\path\to\scratch\run_pressure.py
python C:\path\to\scratch\adversarial_pressure.py
python C:\path\to\scratch\test_pressure.py
```

These commands replace the two trace files in that scratch directory. They create and clean up temporary source roots and independent histories. Live timestamps, paths, and Git commit identifiers can differ from the archived run. The saved-record replay tests, rather than bit-identical fresh captures, are the deterministic reconstruction route. The scripts do not modify production files or append to the repository's canonical trace.

Read `PUBLIC_ASSOCIATION.md` before interpreting `public_reader.py`. It is an experimental supplied contract, not a claim that the current production result already carries an association. The reader accepts a detached packet path and a target record ID; its interpretation requires no DME imports. Recorded packet URIs point to temporary paths from the original run, which are now unavailable. For a manual replay, place the corresponding archived history at a chosen local path and explicitly substitute its file URI in the packet; do not treat this relocation as evidence that the original endpoint persists.

`selection_trace.json` preserves the initial 135-cell matrix, 15 histories, complete results, original packets, and initial ablations. `adversarial_trace.json` binds that trace by SHA-256 and adds mixed4, the 48-cell finalist matrix, order/set ablations, and detached reads. `histories/` holds all 16 JSONL specimens. The trace's textual `jsonl` field normalized line endings during reading; the separately archived JSONL files restore the original byte encoding and are checked against each specimen's saved file hash, including `reencoded_H4`.

`manifest.json` gives SHA-256 and byte length for every other archive member. `verification.json` records test and worktree results. `REPORT.md` states one primary investigator status and the remaining tradeoffs. The archive contains no repository patch because this pass changed no repository files.
