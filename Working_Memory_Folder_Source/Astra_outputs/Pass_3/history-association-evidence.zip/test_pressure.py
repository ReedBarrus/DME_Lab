"""Replay and independently check the saved investigator evidence."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from run_pressure import HERE, current, inspect, packet, stored_records, target_of
from adversarial_pressure import FINAL, declaration
from public_reader import read_packet


class AssociationEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.selection = json.loads((HERE / 'selection_trace.json').read_text(encoding='utf-8'))
        cls.adversarial = json.loads((HERE / 'adversarial_trace.json').read_text(encoding='utf-8'))

    def test_all_saved_histories_recommit_validate_and_reproduce_full_result(self):
        specimens = dict(self.selection['specimens'], mixed4=self.adversarial['new_mixed_specimen'])
        with TemporaryDirectory() as temp:
            for name, saved in specimens.items():
                with self.subTest(name=name):
                    path = Path(temp) / f'{name}.jsonl'
                    recreated = stored_records(path, saved['records'])
                    self.assertEqual(recreated, saved['records'])
                    checked = inspect(path)
                    self.assertEqual(checked['result'], saved['result'])
                    self.assertTrue(all(checked['health'].values()))

    def test_finalists_accept_exactly_the_original_prefix_in_saved_matrix(self):
        specimens = dict(self.selection['specimens'], mixed4=self.adversarial['new_mixed_specimen'])
        original = specimens['H4']['records']
        for row in self.adversarial['matrix']:
            with self.subTest(kind=row['kind'], history=row['available_history']):
                candidate = specimens[row['available_history']]['records']
                # Direct full record comparison, not a second hash formula.
                self.assertEqual(row['outcome']['status'] == 'recovered', candidate[:4] == original)

    def test_original_acquisition_counterexample_defeats_locator_ids_and_terminal(self):
        specimens = self.selection['specimens']
        self.assertEqual(specimens['H4']['result'], specimens['D4']['result'])
        bad = specimens['D4']['records'][1]['envelope']['observation']['signal']['payload']
        self.assertEqual(len(bad['capture_errors']), 3)
        for kind in ('locator_only', 'extent', 'record_ids', 'terminal_digest'):
            row = next(r for r in self.selection['matrix'] if r['kind'] == kind and r['available_history'] == 'D4')
            self.assertEqual(row['outcome']['status'], 'recovered')
            self.assertEqual(row['outcome']['historical_git']['head_sha'], None)

    def test_each_removed_set_member_leaves_a_valid_undiscriminated_prefix(self):
        self.assertEqual(len(self.adversarial['set_ablations']), 4)
        for row in self.adversarial['set_ablations']:
            self.assertTrue(row['same_complete_result'])
            self.assertTrue(row['weakened_subset_rule_accepts_wrong_prefix'])
            self.assertTrue(row['full_set_rule_rejects'])
        self.assertTrue(all(row['outcome']['status'] == 'recovered' for row in self.adversarial['order_ablation']))

    def test_extensions_keep_original_record_and_do_not_claim_current_tail(self):
        self.assertTrue(self.adversarial['whole_current_history_uniqueness_refuted'])
        for row in self.adversarial['extensions']:
            self.assertEqual(row['outcome']['status'], 'recovered')
            self.assertLess(row['outcome']['prefix_record_count'], row['outcome']['available_record_count'])
            self.assertEqual(row['outcome']['current_external_state'], 'unobserved')
        self.assertTrue(all(row['outcome']['status'] == 'mismatched_commitment'
                            for row in self.selection['extensions'] if row['kind'] == 'exact_bytes'))

    def test_detached_process_reads_preserve_data_and_distinguish_recorded_errors(self):
        self.assertEqual(len(self.adversarial['detached_reads']), 9)
        for row in self.adversarial['detached_reads']:
            self.assertTrue(row['ledger_unchanged'])
            self.assertEqual(row['outcome']['status'], 'recovered')
            errors = row['outcome']['historical_git']['capture_errors']
            self.assertEqual(bool(errors), row['source'] == 'D4')

    def test_role_swap_is_rejected_even_if_supplied_commitment_matches_wrong_history(self):
        h4 = self.selection['specimens']['H4']
        roles = self.selection['specimens']['roles4']
        with TemporaryDirectory() as temp:
            path = Path(temp) / 'role_swap.jsonl'
            stored_records(path, roles['records'])
            for kind in FINAL:
                mixed_packet = declaration(kind, roles, path.as_uri())
                mixed_packet['result'] = h4['result']
                self.assertEqual(read_packet(mixed_packet, target_of(h4['result']))['status'], 'mismatched_reference')

    def test_location_and_interpretation_cannot_be_silently_invented(self):
        for row in self.adversarial['locator_and_commitment_ablation']:
            self.assertEqual(row['no_locator']['status'], 'unresolved_location')
            self.assertEqual(row['no_public_contract']['status'], 'unresolved_interpretation')
            self.assertEqual(row['commitment_check_removed']['status'], 'recovered')
            self.assertEqual(row['full_candidate']['status'], 'mismatched_commitment')

    def test_trace_binding_and_canonical_history_conservation(self):
        actual = hashlib.sha256((HERE / 'selection_trace.json').read_bytes()).hexdigest()
        self.assertEqual(actual, self.adversarial['selection_trace_sha256'])
        self.assertEqual(self.selection['canonical_history_sha256_before'], self.selection['canonical_history_sha256_after'])
        self.assertTrue(self.adversarial['functional_equivalence_on_matrix'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
